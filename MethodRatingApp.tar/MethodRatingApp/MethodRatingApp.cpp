#include <iostream>
#include <string>
#include <iomanip>
#include "MethodRating.h"
using namespace std;
//function that displays output
void display(MethodRating method);

int main() {
//declaring instances

//instance Dine in
MethodRating DineIn;
DineIn.setmethod("Dine In");
DineIn.setnumservrateeq1(0);
DineIn.setnumservrateeq2(1);
DineIn.setnumservrateeq3(17);
DineIn.setnumservrateeq4(16);
DineIn.setnumservrateeq5(10);

//instance Drive-Thru
MethodRating DriveThru("Drive-Thru");
    DriveThru.setnumservrateeq1(0);
    DriveThru.setnumservrateeq2(1);
    DriveThru.setnumservrateeq3(9);
    DriveThru.setnumservrateeq4(9);
    DriveThru.setnumservrateeq5(1);

    //instance Take away
    MethodRating Takeaway("Take away");
    Takeaway.setnumservrateeq1(0);
    Takeaway.setnumservrateeq2(2);
    Takeaway.setnumservrateeq3(9);
    Takeaway.setnumservrateeq4(25);
    Takeaway.setnumservrateeq5(12);


//display data
    display(DineIn);
    display(DriveThru);
    display(Takeaway);
    return 0;
}


//display function
void display(MethodRating method){

    //displaying to match sample run
    cout<<"                       Method:   "<<method.getmethod()<<endl;
    cout<<setw(8)<<"Num Serve Ratings Eq1:"<< setw(9)
    <<method.getnumservrateeq1()<<endl;

    cout<<setw(8)<<"Num Serve Ratings Eq2:"<< setw(9)
        <<method.getnumservrateeq2()<<endl;

    cout<<setw(8)<<"Num Serve Ratings Eq3:"<< setw(9)
        <<method.getnumservrateeq3()<<endl;

    cout<<setw(8)<<"Num Serve Ratings Eq4:"<< setw(9)
        <<method.getnumservrateeq4()<<endl;

    cout<<setw(8)<<"Num Serve Ratings Eq5:"<< setw(9)
        <<method.getnumservrateeq5()<<endl;

    cout<<"              Per Rating >= 4:   "<<
    method.computeAvgRatingGT4()<<endl<<endl;


}
