//
// Created by kianw on 11/27/2022.
//
#include <iostream>
#include <string>
using namespace std;


#ifndef METHODRATINGAPP_METHODRATING_H
#define METHODRATINGAPP_METHODRATING_H


class MethodRating {
private:
    string Method;
    int NumServRateEq1;
    int NumServRateEq2;
    int NumServRateEq3;
    int NumServRateEq4;
    int NumServRateEq5;
public:
    //constructers
    MethodRating();
    MethodRating(string m);
    //mutators
    void setmethod(string m);
    void setnumservrateeq1(int num);
    void setnumservrateeq2(int num);
    void setnumservrateeq3(int num);
    void setnumservrateeq4(int num);
    void setnumservrateeq5(int num);
    //accessors
    const string getmethod() const;
    const int getnumservrateeq1() const;
    const int getnumservrateeq2() const;
    const int getnumservrateeq3() const;
    const int getnumservrateeq4() const;
    const int getnumservrateeq5() const;
    //find percent above 4
    const double computeAvgRatingGT4() const;

};


#endif //METHODRATINGAPP_METHODRATING_H
