//
// Created by kianw on 11/27/2022.
//

#include "MethodRating.h"
#include <iostream>
#include <cstdlib>
using namespace std;
//default constructer
MethodRating::MethodRating() {
    Method = "";
    NumServRateEq1 = 0;
    NumServRateEq2 = 0;
    NumServRateEq3 = 0;
    NumServRateEq4 = 0;
    NumServRateEq5 = 0;
}
//constructer that accepts method
MethodRating::MethodRating(std::string m) {
Method = m;
    NumServRateEq1 = 0;
    NumServRateEq2 = 0;
    NumServRateEq3 = 0;
    NumServRateEq4 = 0;
    NumServRateEq5 = 0;

}
// mutators
void MethodRating::setmethod(std::string m) {
    Method = m;

}
void MethodRating::setnumservrateeq1(int num) {
    NumServRateEq1 = num;
}
void MethodRating::setnumservrateeq2(int num) {
    NumServRateEq2 = num;
}
void MethodRating::setnumservrateeq3(int num) {
    NumServRateEq3 = num;
}
void MethodRating::setnumservrateeq4(int num) {
    NumServRateEq4 = num;
}
void MethodRating::setnumservrateeq5(int num) {
    NumServRateEq5 = num;
}

//accessors
const string MethodRating::getmethod() const {
    return Method;
}
const int MethodRating::getnumservrateeq1() const {
    return NumServRateEq1;
}
const int MethodRating::getnumservrateeq2() const {
    return NumServRateEq2;
}
const int MethodRating::getnumservrateeq3() const {
    return NumServRateEq3;
}
const int MethodRating::getnumservrateeq4() const {
    return NumServRateEq4;
}
const int MethodRating::getnumservrateeq5() const {
    return NumServRateEq5;
}

//find percent function
const double MethodRating::computeAvgRatingGT4() const {
    double Percent;
    double total;
    double amount;
    total = NumServRateEq1 + NumServRateEq2 + NumServRateEq3 +
            NumServRateEq4 + NumServRateEq5;
    amount = NumServRateEq4 + NumServRateEq5;
    Percent = amount / total;
    Percent *= 100;
    return Percent;

}
